# Aura Widget — AMOLED Home-Screen Widget

A production-structured Android Studio project for a dark, neon-accented home-screen
widget: live-ish clock, full date, days-left-in-2026 countdown, battery/RAM/storage
status, and a Settings screen for customization. Built with Kotlin, Jetpack Glance,
Jetpack Compose, DataStore, and WorkManager. Targets Android 8.0+ (API 26), tested
against Android 14/15 behavior to match the Infinix Note 40 Pro.

## Opening the project

> **Note on the Gradle wrapper:** `gradle/wrapper/gradle-wrapper.properties` (pointing
> at Gradle 8.7) is included, but the wrapper's binary `gradle-wrapper.jar` is not,
> since it's a compiled binary rather than source text. Android Studio handles this
> transparently — on first open it will prompt **"Gradle wrapper is missing, use
> Gradle from... "** or similar; choose **OK** to let it regenerate the jar
> automatically (or run **File → Sync Project with Gradle Files**). No manual step is
> needed beyond that one prompt.

1. Unzip this project.
2. Android Studio (Koala/2024.1 or newer) → **Open** → select the `InfinixAuraWidget` folder.
3. Let Gradle sync (it will download the Gradle 8.7 wrapper, AGP 8.5.2, and the
   dependencies listed in `app/build.gradle.kts` — an internet connection is required
   for this step, same as any new Android project).
4. Run the `app` configuration on a device or emulator running API 26+.
5. Long-press the home screen → Widgets → **Aura AMOLED Widget** → drag it onto the
   home screen. Android will immediately open the Settings screen to configure it.

## Project layout

```
app/src/main/kotlin/com/aura/widget/
  MainActivity.kt              Launcher screen: instructions + link to Settings
  widget/
    AuraWidget.kt               The Glance composable UI (adaptive small/medium/large)
    AuraWidgetReceiver.kt       System entry point; starts/stops the refresh chain
    AuraWidgetUpdateWorker.kt   WorkManager-based refresh engine (see below)
    BootRestartReceiver.kt      Belt-and-suspenders re-arm after device reboot
  settings/
    SettingsActivity.kt         Doubles as the widget's configure Activity + standalone Settings
    SettingsScreen.kt           Compose UI: switches, sliders, accent-color picker
  data/
    SystemStatsRepository.kt    Aggregates battery/thermal/RAM/storage into one snapshot
    WidgetSettingsRepository.kt DataStore-backed persistence for user preferences
  model/
    WidgetSettings.kt           User-configurable appearance/behavior
    SystemStats.kt              Device state snapshot shown in the widget
  utils/
    DateTimeUtils.kt            Clock/date formatting + year-end countdown math
    BatteryUtils.kt             Battery %, charging state, temperature, thermal status
    MemoryUtils.kt              RAM usage via ActivityManager
    StorageUtils.kt             Internal storage usage via StatFs
    FormatUtils.kt              Byte → "X.X GB" / percentage helpers
  ui/
    WidgetTheme.kt              Centralized AMOLED/neon color + styling decisions
```

## Why some things work the way they do (real Android platform constraints)

This app is built to actually run correctly on a real device, which means respecting a
few hard platform limits rather than pretending they don't exist:

- **No true per-second clock.** Android does not deliver a system tick to background
  apps faster than about once a minute, and `AppWidgetProviderInfo.updatePeriodMillis`
  is floored at ~30 minutes by the OS. This project reaches the practical ceiling — a
  refresh close to once a minute — using a **self-chaining WorkManager job**
  (`AuraWidgetUpdateWorker`): each run refreshes the widget and schedules the next run,
  which has no minimum-interval floor the way `PeriodicWorkRequest` does (floored at 15
  min). A 15-minute periodic "safety net" guarantees the widget never goes stale even if
  the chain is ever interrupted. This avoids needing the `SCHEDULE_EXACT_ALARM`
  permission, which Google Play policy restricts to genuine alarm-clock apps.
- **No blur/glassmorphism, particle effects, or video backgrounds.** The surface
  Android widgets render to (RemoteViews, which Glance compiles down to) has no blur
  primitive and cannot host video or particle systems. The "glass" look here comes from
  layered translucent panels + a subtle border + true-black backing — the same
  technique real widget apps use. See the comments in `WidgetTheme.kt`.
- **No raw CPU temperature.** Android does not expose per-core SoC temperature to
  third-party apps. `BatteryUtils.readThermalStatus()` uses `PowerManager`'s official
  thermal-status API (API 29+) as the closest sanctioned signal instead.
- **True black, not dark gray.** All large surfaces use `#000000` specifically —on an
  AMOLED panel those pixels switch off entirely, which is what actually saves battery.

## Customization

Open the widget's Settings (via the configure flow on placement, or from the app's
launcher screen) to adjust: 12/24-hour clock, accent color, font size, background
transparency, corner roundness, which info rows are shown, and refresh cadence
("Battery saver" vs "Balanced" vs "High responsiveness").

## Known follow-ups not yet included

This is a solid, buildable core. Not yet built out: automatic Material You / wallpaper
color extraction, a home-screen-preview mock in Settings, and instrumented/unit test
coverage. Happy to add any of these next — just ask.

# Keep Glance widget receiver classes discoverable by the AppWidget host.
-keep class com.aura.widget.widget.** { *; }

# Keep DataStore preference keys (reflection-free, but keep for safety with R8 full mode).
-keep class androidx.datastore.preferences.protobuf.** { *; }

# Kotlin coroutines / WorkManager
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler
-keep class androidx.work.impl.WorkDatabase { *; }

# Compose compiler metadata (standard, non-shrinkable) — keep line numbers for crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

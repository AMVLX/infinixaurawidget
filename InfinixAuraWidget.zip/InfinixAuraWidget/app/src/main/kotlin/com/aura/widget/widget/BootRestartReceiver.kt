package com.aura.widget.widget

import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/**
 * WorkManager's own scheduled work already survives reboot on modern Android (it persists
 * to disk and Android re-triggers it). This receiver exists as a belt-and-suspenders check:
 * it only re-arms the chain if, for some reason, no widget instances are currently tracked
 * as having active work (e.g. a very old OS quirk or an OEM battery-management app that
 * aggressively wiped WorkManager's job store, which is common on some devices).
 */
class BootRestartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val appWidgetManager = AppWidgetManager.getInstance(context)
        val ids = appWidgetManager.getAppWidgetIds(ComponentName(context, AuraWidgetReceiver::class.java))

        if (ids.isNotEmpty()) {
            AuraWidgetUpdateWorker.startAll(context)
        }
    }
}

package com.aura.widget.widget

import android.content.Context
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver

/**
 * The system-facing entry point for the widget. Glance requires this thin subclass to
 * bridge AppWidgetProvider's lifecycle callbacks into [AuraWidget]'s composable UI.
 */
class AuraWidgetReceiver : GlanceAppWidgetReceiver() {

    override val glanceAppWidget: GlanceAppWidget = AuraWidget()

    /** Called once when the *first* instance of this widget is placed on any home screen. */
    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        AuraWidgetUpdateWorker.startAll(context)
    }

    /** Called once when the *last* instance of this widget is removed. */
    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        AuraWidgetUpdateWorker.cancelAll(context)
    }
}

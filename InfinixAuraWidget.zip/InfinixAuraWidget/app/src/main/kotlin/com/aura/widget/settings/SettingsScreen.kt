package com.aura.widget.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aura.widget.data.WidgetSettingsRepository
import com.aura.widget.model.PerformanceMode
import com.aura.widget.model.WidgetSettings
import kotlinx.coroutines.launch

private val accentPresets = listOf(
    0xFF00E5FFL, // cyan
    0xFFB388FFL, // violet
    0xFFFF4FA0L, // pink
    0xFFC6FF00L, // lime
    0xFFFFC400L  // amber
)

@Composable
fun SettingsScreen(
    repository: WidgetSettingsRepository,
    onSave: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(WidgetSettings()) }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        settings = repository.current()
        loaded = true
    }

    if (!loaded) return

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "Aura Widget Settings",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.headlineSmall
        )

        SectionSpacer()

        SettingSwitchRow(
            label = "24-hour clock",
            checked = settings.use24HourClock,
            onCheckedChange = { settings = settings.copy(use24HourClock = it) }
        )

        SettingSwitchRow(
            label = "Show year countdown",
            checked = settings.showCountdown,
            onCheckedChange = { settings = settings.copy(showCountdown = it) }
        )

        SettingSwitchRow(
            label = "Show battery info",
            checked = settings.showBatteryInfo,
            onCheckedChange = { settings = settings.copy(showBatteryInfo = it) }
        )

        SettingSwitchRow(
            label = "Show RAM & storage",
            checked = settings.showRamAndStorage,
            onCheckedChange = { settings = settings.copy(showRamAndStorage = it) }
        )

        SectionSpacer()
        Text("Accent color", color = Color(0xB3FFFFFF), style = MaterialTheme.typography.labelLarge)
        Row(modifier = Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            accentPresets.forEach { argb ->
                val color = Color(argb.toInt())
                val isSelected = settings.accentColorArgb == argb
                Column(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(color)
                        .clickable { settings = settings.copy(accentColorArgb = argb) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isSelected) {
                        Text("✓", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        SectionSpacer()
        LabeledSlider(
            label = "Font size",
            value = settings.fontScale,
            valueRange = 0.85f..1.3f,
            display = "${(settings.fontScale * 100).toInt()}%",
            onValueChange = { settings = settings.copy(fontScale = it) }
        )

        LabeledSlider(
            label = "Background transparency",
            value = settings.backgroundAlpha,
            valueRange = 0f..0.6f,
            display = "${(settings.backgroundAlpha * 100).toInt()}%",
            onValueChange = { settings = settings.copy(backgroundAlpha = it) }
        )

        LabeledSlider(
            label = "Corner roundness",
            value = settings.cornerRadiusDp.toFloat(),
            valueRange = 0f..40f,
            display = "${settings.cornerRadiusDp}dp",
            onValueChange = { settings = settings.copy(cornerRadiusDp = it.toInt()) }
        )

        SectionSpacer()
        Text("Refresh mode", color = Color(0xB3FFFFFF), style = MaterialTheme.typography.labelLarge)
        Text(
            text = "Controls how often the widget refreshes in the background. " +
                "\"Battery saver\" checks every 15 minutes; the others aim for close " +
                "to once a minute — the practical ceiling for any Android home-screen widget.",
            color = Color(0x80FFFFFF),
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerformanceMode.values().forEach { mode ->
                val selected = settings.performanceMode == mode
                Text(
                    text = mode.name.replace('_', ' '),
                    color = if (selected) Color.Black else Color.White,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (selected) Color(0xFF00E5FF) else Color(0x33FFFFFF))
                        .clickable { settings = settings.copy(performanceMode = mode) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }

        SectionSpacer()
        Button(onClick = {
            scope.launch {
                repository.update { settings }
                onSave()
            }
        }) {
            Text("Save")
        }
    }
}

@Composable
private fun SettingSwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, style = MaterialTheme.typography.bodyLarge)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFF00E5FF))
        )
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    display: String,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            Text(display, color = Color(0x80FFFFFF), style = MaterialTheme.typography.bodyMedium)
        }
        Slider(value = value, valueRange = valueRange, onValueChange = onValueChange)
    }
}

@Composable
private fun SectionSpacer() {
    HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(vertical = 14.dp))
}

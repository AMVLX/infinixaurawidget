package com.aura.widget.utils

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.aura.widget.model.ThermalStatus

/**
 * Wraps the sticky ACTION_BATTERY_CHANGED broadcast and PowerManager's thermal API.
 * No permissions are required for either — both are public, permission-free system APIs.
 */
object BatteryUtils {

    data class BatterySnapshot(
        val percent: Int,
        val isCharging: Boolean,
        val temperatureCelsius: Float?
    )

    /**
     * Reads the last-known battery broadcast. Because ACTION_BATTERY_CHANGED is a
     * *sticky* broadcast, registering a receiver for it with a null Context returns
     * immediately with the most recent value — no need to keep a receiver registered
     * for the app's whole lifetime, which is what makes this safe to call from a
     * short-lived WorkManager job.
     */
    fun readBattery(context: Context): BatterySnapshot {
        val intent: Intent? = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100) / scale else 0

        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        // EXTRA_TEMPERATURE is reported in tenths of a degree Celsius, e.g. 315 == 31.5°C.
        val rawTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?: Int.MIN_VALUE
        val temperature = if (rawTemp != Int.MIN_VALUE) rawTemp / 10f else null

        return BatterySnapshot(percent, isCharging, temperature)
    }

    /**
     * Android intentionally does not expose a raw numeric CPU temperature to third-party
     * apps (it varies by SoC vendor and has been used for fingerprinting in the past).
     * PowerManager.getCurrentThermalStatus() (API 29+) is Google's official, sanctioned
     * substitute: a coarse enum reflecting overall device thermal pressure, which is what
     * this app surfaces instead of a fabricated or reverse-engineered "CPU temp" number.
     */
    fun readThermalStatus(context: Context): ThermalStatus {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return ThermalStatus.UNAVAILABLE

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            ?: return ThermalStatus.UNAVAILABLE

        return when (powerManager.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> ThermalStatus.NONE
            PowerManager.THERMAL_STATUS_LIGHT -> ThermalStatus.LIGHT
            PowerManager.THERMAL_STATUS_MODERATE -> ThermalStatus.MODERATE
            PowerManager.THERMAL_STATUS_SEVERE -> ThermalStatus.SEVERE
            PowerManager.THERMAL_STATUS_CRITICAL -> ThermalStatus.CRITICAL
            PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalStatus.EMERGENCY
            PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalStatus.SHUTDOWN
            else -> ThermalStatus.UNAVAILABLE
        }
    }
}

package com.aura.widget.utils

import android.os.Environment
import android.os.StatFs

object StorageUtils {

    data class StorageSnapshot(val usedBytes: Long, val totalBytes: Long)

    /** Reports usage of the primary internal storage volume (matches Settings > Storage). */
    fun readStorage(): StorageSnapshot {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        return StorageSnapshot(usedBytes = total - free, totalBytes = total)
    }
}

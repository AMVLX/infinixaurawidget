package com.aura.widget.settings

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.aura.widget.data.WidgetSettingsRepository
import com.aura.widget.widget.AuraWidgetUpdateWorker

/**
 * Two entry paths lead here, and both are handled correctly:
 *  1. The OS launches this Activity automatically right after the user drags the widget
 *     onto their home screen (declared via android:configure in aura_widget_info.xml).
 *     In this path, [AppWidgetManager.EXTRA_APPWIDGET_ID] is present, and Android *requires*
 *     us to call setResult(RESULT_OK, ...) before finishing or the whole widget placement
 *     is silently cancelled by the host.
 *  2. The user opens Settings later from [com.aura.widget.MainActivity]. In this path
 *     there is no app widget id — we just persist settings and let the background
 *     worker pick them up on its next tick (or refresh immediately, see below).
 */
class SettingsActivity : ComponentActivity() {

    private var appWidgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        // Per Android's widget-configuration contract: if the host cancels/backs out
        // before we explicitly confirm, default to CANCELED so no half-configured
        // widget gets stuck on the home screen.
        setResult(Activity.RESULT_CANCELED)

        val repository = WidgetSettingsRepository(applicationContext)

        setContent {
            MaterialTheme {
                Surface(color = Color.Black, modifier = Modifier.fillMaxSize()) {
                    SettingsScreen(
                        repository = repository,
                        onSave = { onSettingsSaved() }
                    )
                }
            }
        }
    }

    private fun onSettingsSaved() {
        // Kick an immediate refresh so the user sees their changes reflected on the
        // home screen right away, instead of waiting for the next scheduled tick.
        AuraWidgetUpdateWorker.refreshNow(applicationContext)

        if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            setResult(Activity.RESULT_OK, resultValue)
        }
        finish()
    }
}

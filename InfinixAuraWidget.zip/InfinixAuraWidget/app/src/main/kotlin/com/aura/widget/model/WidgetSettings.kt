package com.aura.widget.model

/**
 * Immutable snapshot of everything the user can customize about the widget's
 * appearance and behavior. Persisted via [com.aura.widget.data.WidgetSettingsRepository]
 * using DataStore Preferences.
 */
data class WidgetSettings(
    val use24HourClock: Boolean = true,
    val accentColorArgb: Long = 0xFF00E5FFL, // aura_neon_cyan
    val fontScale: Float = 1.0f,             // 0.85 .. 1.3
    val backgroundAlpha: Float = 0.24f,      // 0f (fully transparent) .. 0.6f (near opaque)
    val cornerRadiusDp: Int = 28,
    val showBatteryInfo: Boolean = true,
    val showCountdown: Boolean = true,
    val showRamAndStorage: Boolean = true,
    val performanceMode: PerformanceMode = PerformanceMode.BALANCED
)

/**
 * Governs how aggressively the background worker refreshes widget content.
 * Exposed in Settings as "performance mode" per the original spec.
 */
enum class PerformanceMode(val refreshMinutes: Long) {
    /** Refreshes every 15 minutes. Best battery life, clock may lag up to 15 min. */
    BATTERY_SAVER(15L),
    /** Refreshes every minute — the practical ceiling for widget updates on Android. */
    BALANCED(1L),
    /** Also every minute (the OS floor), but additionally listens to explicit broadcasts
     *  (screen-on, time-tick, battery-changed) for the snappiest possible feel. */
    HIGH_RESPONSIVENESS(1L)
}

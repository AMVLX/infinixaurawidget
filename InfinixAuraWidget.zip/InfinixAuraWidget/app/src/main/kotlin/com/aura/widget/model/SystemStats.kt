package com.aura.widget.model

/**
 * A single immutable snapshot of everything the widget displays that comes from
 * device hardware/OS state, as opposed to pure calendar math.
 */
data class SystemStats(
    val batteryPercent: Int,
    val isCharging: Boolean,
    val batteryTemperatureCelsius: Float?,   // null if the OS didn't report it in time
    val thermalStatus: ThermalStatus,        // closest available proxy for "CPU temperature"
    val ramUsedBytes: Long,
    val ramTotalBytes: Long,
    val storageUsedBytes: Long,
    val storageTotalBytes: Long
) {
    val ramUsedFraction: Float
        get() = if (ramTotalBytes > 0) ramUsedBytes.toFloat() / ramTotalBytes else 0f

    val storageUsedFraction: Float
        get() = if (storageTotalBytes > 0) storageUsedBytes.toFloat() / storageTotalBytes else 0f

    companion object {
        val EMPTY = SystemStats(
            batteryPercent = 0,
            isCharging = false,
            batteryTemperatureCelsius = null,
            thermalStatus = ThermalStatus.NONE,
            ramUsedBytes = 0L,
            ramTotalBytes = 0L,
            storageUsedBytes = 0L,
            storageTotalBytes = 0L
        )
    }
}

/**
 * Mirrors android.os.PowerManager's THERMAL_STATUS_* constants (API 29+).
 * Android does not expose a raw per-core CPU temperature to apps for privacy/security
 * reasons — this thermal status is the officially sanctioned, closest available signal,
 * which is why it's used here instead of a numeric "CPU temp" the spec originally asked for.
 */
enum class ThermalStatus {
    NONE, LIGHT, MODERATE, SEVERE, CRITICAL, EMERGENCY, SHUTDOWN, UNAVAILABLE
}

package com.aura.widget.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.aura.widget.model.PerformanceMode
import com.aura.widget.model.WidgetSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "aura_widget_settings")

/**
 * Persists [WidgetSettings] via Jetpack DataStore. Exposed both as a suspend "get once"
 * function (used by the widget refresh worker, which just needs a snapshot) and as a
 * [Flow] (used by the Settings screen, which wants live updates while the user is
 * dragging a slider or toggling a switch).
 */
class WidgetSettingsRepository(private val context: Context) {

    private object Keys {
        val USE_24_HOUR = booleanPreferencesKey("use_24_hour_clock")
        val ACCENT_COLOR = longPreferencesKey("accent_color_argb")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val BACKGROUND_ALPHA = floatPreferencesKey("background_alpha")
        val CORNER_RADIUS = intPreferencesKey("corner_radius_dp")
        val SHOW_BATTERY = booleanPreferencesKey("show_battery_info")
        val SHOW_COUNTDOWN = booleanPreferencesKey("show_countdown")
        val SHOW_RAM_STORAGE = booleanPreferencesKey("show_ram_and_storage")
        val PERFORMANCE_MODE = stringPreferencesKey("performance_mode")
    }

    val settingsFlow: Flow<WidgetSettings> = context.settingsDataStore.data.map { prefs ->
        WidgetSettings(
            use24HourClock = prefs[Keys.USE_24_HOUR] ?: true,
            accentColorArgb = prefs[Keys.ACCENT_COLOR] ?: 0xFF00E5FFL,
            fontScale = prefs[Keys.FONT_SCALE] ?: 1.0f,
            backgroundAlpha = prefs[Keys.BACKGROUND_ALPHA] ?: 0.24f,
            cornerRadiusDp = prefs[Keys.CORNER_RADIUS] ?: 28,
            showBatteryInfo = prefs[Keys.SHOW_BATTERY] ?: true,
            showCountdown = prefs[Keys.SHOW_COUNTDOWN] ?: true,
            showRamAndStorage = prefs[Keys.SHOW_RAM_STORAGE] ?: true,
            performanceMode = prefs[Keys.PERFORMANCE_MODE]
                ?.let { runCatching { PerformanceMode.valueOf(it) }.getOrNull() }
                ?: PerformanceMode.BALANCED
        )
    }

    suspend fun current(): WidgetSettings = settingsFlow.first()

    suspend fun update(transform: (WidgetSettings) -> WidgetSettings) {
        val newSettings = transform(current())
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.USE_24_HOUR] = newSettings.use24HourClock
            prefs[Keys.ACCENT_COLOR] = newSettings.accentColorArgb
            prefs[Keys.FONT_SCALE] = newSettings.fontScale
            prefs[Keys.BACKGROUND_ALPHA] = newSettings.backgroundAlpha
            prefs[Keys.CORNER_RADIUS] = newSettings.cornerRadiusDp
            prefs[Keys.SHOW_BATTERY] = newSettings.showBatteryInfo
            prefs[Keys.SHOW_COUNTDOWN] = newSettings.showCountdown
            prefs[Keys.SHOW_RAM_STORAGE] = newSettings.showRamAndStorage
            prefs[Keys.PERFORMANCE_MODE] = newSettings.performanceMode.name
        }
    }
}

package com.aura.widget.widget

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.aura.widget.data.WidgetSettingsRepository
import java.util.concurrent.TimeUnit

/**
 * Drives every widget refresh. There is no per-second (or even per-minute) system tick
 * that Android delivers to a background app for free — this worker is what stands in
 * for one, built entirely on WorkManager so it stays battery- and Doze-respectful
 * without needing any special "exact alarm" permission (which Play policy restricts to
 * genuine alarm-clock apps and which Android 12+ requires the user to grant manually).
 *
 * Two mechanisms cooperate:
 *  1. A self-chaining OneTimeWorkRequest ("the tick"): each run refreshes the widget,
 *     then enqueues the *next* run some [PerformanceMode.refreshMinutes] later. One-time
 *     work has no minimum-interval floor, unlike PeriodicWorkRequest (floored at 15 min
 *     by the platform) or AppWidgetProviderInfo.updatePeriodMillis (floored at ~30 min).
 *     This is what lets "Balanced" mode feel close to a live, once-a-minute clock.
 *  2. A 15-minute PeriodicWorkRequest ("the safety net"): if the chain above is ever
 *     broken — e.g. the OS clears WorkManager's DB, or the device stays in deep Doze
 *     long enough that the chain gets batched/delayed — this guarantees the widget
 *     never goes stale for more than 15 minutes.
 */
class AuraWidgetUpdateWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            AuraWidget().updateAll(applicationContext)

            // Re-arm the next tick using whatever cadence the user picked in Settings.
            // Reading settings fresh here (rather than baking the interval into the
            // request at schedule-time) means a mode change takes effect on the very
            // next tick, with no need to cancel/reschedule from the Settings screen.
            val settings = WidgetSettingsRepository(applicationContext).current()
            scheduleNextTick(applicationContext, settings.performanceMode.refreshMinutes)

            Result.success()
        } catch (t: Throwable) {
            // Transient failures (e.g. DataStore momentarily unavailable) get retried
            // with WorkManager's default exponential backoff rather than silently
            // freezing the widget until the next safety-net tick.
            Result.retry()
        }
    }

    companion object {
        private const val TICK_CHAIN_WORK_NAME = "aura_widget_tick_chain"
        private const val SAFETY_NET_WORK_NAME = "aura_widget_safety_net"

        private fun scheduleNextTick(context: Context, delayMinutes: Long) {
            val request = OneTimeWorkRequestBuilder<AuraWidgetUpdateWorker>()
                .setInitialDelay(delayMinutes.coerceAtLeast(1L), TimeUnit.MINUTES)
                .addTag(TICK_CHAIN_WORK_NAME)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                TICK_CHAIN_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        private fun scheduleSafetyNet(context: Context) {
            val request = PeriodicWorkRequestBuilder<AuraWidgetUpdateWorker>(15, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                SAFETY_NET_WORK_NAME,
                // KEEP: don't reset the safety net's own timer just because settings changed
                // or the app restarted — it only needs to exist, not to be perfectly aligned.
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        /** Call when the first widget instance is placed (or on boot / process restart). */
        fun startAll(context: Context, initialTickDelayMinutes: Long = 1L) {
            scheduleNextTick(context, initialTickDelayMinutes)
            scheduleSafetyNet(context)
        }

        /** Call when the last widget instance is removed, so nothing keeps ticking for no reason. */
        fun cancelAll(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(TICK_CHAIN_WORK_NAME)
            WorkManager.getInstance(context).cancelUniqueWork(SAFETY_NET_WORK_NAME)
        }

        /** Forces an immediate refresh — used by the "Sync now" action and after Settings are saved. */
        fun refreshNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<AuraWidgetUpdateWorker>().build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "aura_widget_manual_refresh",
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}

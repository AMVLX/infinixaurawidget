package com.aura.widget.data

import android.content.Context
import com.aura.widget.model.SystemStats
import com.aura.widget.utils.BatteryUtils
import com.aura.widget.utils.MemoryUtils
import com.aura.widget.utils.StorageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Single source of truth for "everything about the device's current hardware state"
 * that the widget cares about. Sits in the Repository layer of the MVVM/Clean
 * Architecture split: the widget/worker layer never touches BatteryManager,
 * ActivityManager, or StatFs directly — only this repository does.
 */
class SystemStatsRepository(private val context: Context) {

    /** All reads are cheap, synchronous OS calls, but dispatched on IO to keep the
     *  worker/composition thread free, and to make this trivially unit-testable by
     *  swapping the dispatcher in tests. */
    suspend fun snapshot(): SystemStats = withContext(Dispatchers.IO) {
        val battery = BatteryUtils.readBattery(context)
        val thermal = BatteryUtils.readThermalStatus(context)
        val ram = MemoryUtils.readRam(context)
        val storage = StorageUtils.readStorage()

        SystemStats(
            batteryPercent = battery.percent,
            isCharging = battery.isCharging,
            batteryTemperatureCelsius = battery.temperatureCelsius,
            thermalStatus = thermal,
            ramUsedBytes = ram.usedBytes,
            ramTotalBytes = ram.totalBytes,
            storageUsedBytes = storage.usedBytes,
            storageTotalBytes = storage.totalBytes
        )
    }
}

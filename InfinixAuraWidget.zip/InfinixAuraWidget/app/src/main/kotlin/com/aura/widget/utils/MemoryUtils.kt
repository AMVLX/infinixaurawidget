package com.aura.widget.utils

import android.app.ActivityManager
import android.content.Context

object MemoryUtils {

    data class RamSnapshot(val usedBytes: Long, val totalBytes: Long)

    /**
     * Reports whole-device RAM usage (not just this app's heap), matching what users
     * expect from a "RAM usage" widget. Requires no special permission — ActivityManager
     * .getMemoryInfo() is a standard public API.
     */
    fun readRam(context: Context): RamSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)

        val total = info.totalMem
        val used = total - info.availMem
        return RamSnapshot(usedBytes = used, totalBytes = total)
    }
}

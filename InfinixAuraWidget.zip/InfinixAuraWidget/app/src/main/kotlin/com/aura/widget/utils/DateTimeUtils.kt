package com.aura.widget.utils

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

/**
 * Pure, stateless date/time helpers. All functions take the current [ZoneId] explicitly
 * rather than caching it, so results stay correct across timezone changes, DST transitions,
 * and locale switches without needing any invalidation logic — the caller (the widget
 * refresh worker) just calls these fresh every tick.
 */
object DateTimeUtils {

    fun now(zone: ZoneId = ZoneId.systemDefault()): LocalDateTime = LocalDateTime.now(zone)

    /** e.g. "14:07:52" or "02:07:52 PM" depending on [use24Hour]. */
    fun formatClock(dateTime: LocalDateTime, use24Hour: Boolean): String {
        val pattern = if (use24Hour) "HH:mm:ss" else "hh:mm:ss a"
        return dateTime.format(java.time.format.DateTimeFormatter.ofPattern(pattern, Locale.getDefault()))
    }

    /** e.g. "9" for day-of-month. */
    fun formatDayOfMonth(dateTime: LocalDateTime): String = dateTime.dayOfMonth.toString()

    /** e.g. "July" */
    fun formatMonthName(dateTime: LocalDateTime): String =
        dateTime.month.getDisplayName(TextStyle.FULL, Locale.getDefault())

    /** e.g. "7" (1-indexed, matching how people naturally read months) */
    fun formatMonthNumber(dateTime: LocalDateTime): String = dateTime.monthValue.toString()

    /** e.g. "2026" */
    fun formatYear(dateTime: LocalDateTime): String = dateTime.year.toString()

    /** e.g. "Thursday" */
    fun formatWeekday(dateTime: LocalDateTime): String =
        dateTime.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault())

    /**
     * Days remaining until 23:59:59 on Dec 31 of [targetYear], inclusive of "today" as day zero.
     * Recomputed fresh from [today] every call, so it self-corrects after reboot, timezone
     * changes, and DST — there is no stored/cached countdown value anywhere in the app.
     */
    fun daysUntilYearEnd(today: LocalDate = LocalDate.now(), targetYear: Int = 2026): Long {
        val yearEnd = LocalDate.of(targetYear, 12, 31)
        return ChronoUnit.DAYS.between(today, yearEnd).coerceAtLeast(0)
    }
}

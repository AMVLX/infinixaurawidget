package com.aura.widget.utils

import kotlin.math.roundToInt

object FormatUtils {
    /** e.g. 6_400_000_000L -> "6.4 GB" */
    fun bytesToGb(bytes: Long): String {
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)
        return "%.1f GB".format(gb)
    }

    fun percentOf(used: Long, total: Long): Int {
        if (total <= 0L) return 0
        return ((used.toDouble() / total.toDouble()) * 100).roundToInt().coerceIn(0, 100)
    }
}

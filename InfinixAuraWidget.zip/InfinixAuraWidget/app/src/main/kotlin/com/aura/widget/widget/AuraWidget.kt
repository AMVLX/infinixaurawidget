package com.aura.widget.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.aura.widget.MainActivity
import com.aura.widget.data.SystemStatsRepository
import com.aura.widget.data.WidgetSettingsRepository
import com.aura.widget.model.SystemStats
import com.aura.widget.model.WidgetSettings
import com.aura.widget.ui.WidgetTheme
import com.aura.widget.utils.DateTimeUtils
import com.aura.widget.utils.FormatUtils
import java.time.LocalDateTime

/**
 * The widget's declarative UI, built with Jetpack Glance — Google's recommended
 * replacement for hand-written RemoteViews XML. Glance still compiles down to
 * RemoteViews under the hood (that's an OS requirement for anything hosted outside
 * your own process), but this file never touches RemoteViews directly.
 *
 * Layout adapts to three size classes via [SizeMode.Responsive] + [LocalSize]:
 * small (info chip), medium (clock + date), large (clock + date + full stats).
 * Nothing is ever cropped — at the smallest size, lower-priority rows are hidden
 * entirely rather than clipped or overlapped.
 */
class AuraWidget : GlanceAppWidget() {

    override val sizeMode = SizeMode.Responsive(
        setOf(
            DpSize(120.dp, 100.dp),  // small
            DpSize(220.dp, 140.dp),  // medium
            DpSize(280.dp, 220.dp)   // large
        )
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val settingsRepo = WidgetSettingsRepository(context)
        val statsRepo = SystemStatsRepository(context)

        val settings = settingsRepo.current()
        val stats = statsRepo.snapshot()

        provideContent {
            GlanceTheme {
                AuraWidgetContent(settings = settings, stats = stats)
            }
        }
    }
}

@Composable
private fun AuraWidgetContent(settings: WidgetSettings, stats: SystemStats) {
    val size = LocalSize.current
    val now = DateTimeUtils.now()
    val accent = WidgetTheme.accent(settings)

    Box(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(WidgetTheme.trueBlack)
            .cornerRadius(settings.cornerRadiusDp.dp)
            .clickable(actionStartActivity<MainActivity>())
    ) {
        // "Glass" panel: a translucent layer + thin border over true black, since
        // Glance has no blur primitive — see WidgetTheme.glassBackground for why.
        Column(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(WidgetTheme.glassBackground(settings))
                .cornerRadius(settings.cornerRadiusDp.dp)
                .padding(14.dp)
        ) {
            ClockRow(now = now, use24Hour = settings.use24HourClock, accent = accent)

            Spacer(modifier = GlanceModifier.height(4.dp))

            DateRow(now = now)

            if (size.height >= 140.dp) {
                Spacer(modifier = GlanceModifier.height(8.dp))
                if (settings.showCountdown) {
                    CountdownRow(accent = accent)
                }
            }

            if (size.height >= 200.dp) {
                Spacer(modifier = GlanceModifier.height(10.dp))
                if (settings.showBatteryInfo || settings.showRamAndStorage) {
                    StatsRow(settings = settings, stats = stats, accent = accent)
                }
            }
        }
    }
}

@Composable
private fun ClockRow(now: LocalDateTime, use24Hour: Boolean, accent: Color) {
    Text(
        text = DateTimeUtils.formatClock(now, use24Hour),
        style = TextStyle(
            color = ColorProvider(WidgetTheme.textPrimary),
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold
        )
    )
}

@Composable
private fun DateRow(now: LocalDateTime) {
    val label = "${DateTimeUtils.formatWeekday(now)}, ${DateTimeUtils.formatMonthName(now)} " +
        "${DateTimeUtils.formatDayOfMonth(now)}, ${DateTimeUtils.formatYear(now)}"
    Text(
        text = label,
        style = TextStyle(
            color = ColorProvider(WidgetTheme.textSecondary),
            fontSize = 13.sp
        )
    )
}

@Composable
private fun CountdownRow(accent: Color) {
    val days = DateTimeUtils.daysUntilYearEnd()
    Row(
        modifier = GlanceModifier.fillMaxWidth(),
        verticalAlignment = Alignment.Vertical.CenterVertically
    ) {
        Text(
            text = "$days days left in 2026",
            style = TextStyle(
                color = ColorProvider(accent),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

@Composable
private fun StatsRow(settings: WidgetSettings, stats: SystemStats, accent: Color) {
    Row(modifier = GlanceModifier.fillMaxWidth()) {
        if (settings.showBatteryInfo) {
            val batteryColor = WidgetTheme.batteryColor(stats.batteryPercent, stats.isCharging)
            Column(modifier = GlanceModifier.padding(end = 12.dp)) {
                Text(
                    text = "${stats.batteryPercent}%" + if (stats.isCharging) " ⚡" else "",
                    style = TextStyle(color = ColorProvider(batteryColor), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                )
                Text(
                    text = "Battery",
                    style = TextStyle(color = ColorProvider(WidgetTheme.textTertiary), fontSize = 9.sp)
                )
            }
        }

        if (settings.showRamAndStorage) {
            Column(modifier = GlanceModifier.padding(end = 12.dp)) {
                Text(
                    text = "${FormatUtils.percentOf(stats.ramUsedBytes, stats.ramTotalBytes)}%",
                    style = TextStyle(color = ColorProvider(WidgetTheme.textPrimary), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                )
                Text(
                    text = "RAM",
                    style = TextStyle(color = ColorProvider(WidgetTheme.textTertiary), fontSize = 9.sp)
                )
            }

            Column {
                Text(
                    text = "${FormatUtils.percentOf(stats.storageUsedBytes, stats.storageTotalBytes)}%",
                    style = TextStyle(color = ColorProvider(WidgetTheme.textPrimary), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                )
                Text(
                    text = "Storage",
                    style = TextStyle(color = ColorProvider(WidgetTheme.textTertiary), fontSize = 9.sp)
                )
            }
        }
    }
}

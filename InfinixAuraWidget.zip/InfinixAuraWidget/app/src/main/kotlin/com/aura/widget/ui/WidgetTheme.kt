package com.aura.widget.ui

import androidx.compose.ui.graphics.Color
import androidx.glance.unit.ColorProvider
import com.aura.widget.model.WidgetSettings

/**
 * Central place for AMOLED/neon styling decisions so widget composables never hardcode
 * colors inline. True black (#000000) is used for every large background surface — on an
 * AMOLED panel those pixels are physically switched off, which is the real source of the
 * battery savings the spec asked for (not just "a dark-looking theme").
 */
object WidgetTheme {
    val trueBlack = Color(0xFF000000)
    val glassWhite = Color(0x3DFFFFFF)
    val glassBorder = Color(0x59FFFFFF)

    val textPrimary = Color(0xFFFFFFFF)
    val textSecondary = Color(0xB3FFFFFF)
    val textTertiary = Color(0x80FFFFFF)

    val batteryOk = Color(0xFF00E676)
    val batteryLow = Color(0xFFFF5252)
    val batteryCharging = Color(0xFFFFC400)

    fun accent(settings: WidgetSettings): Color = Color(settings.accentColorArgb.toInt())

    /** The user's chosen transparency applied over white — this is the "glass" panel the
     *  clock/date/stats sit on top of. Glance can't do real Gaussian blur (no Android widget
     *  surface supports it), so the glassmorphism look here comes from layering this
     *  translucent panel plus a subtle border, which is the closest achievable effect. */
    fun glassBackground(settings: WidgetSettings): Color = Color.White.copy(alpha = settings.backgroundAlpha)

    fun batteryColor(percent: Int, isCharging: Boolean): Color = when {
        isCharging -> batteryCharging
        percent <= 20 -> batteryLow
        else -> batteryOk
    }

    fun provider(color: Color): ColorProvider = ColorProvider(color)
}
